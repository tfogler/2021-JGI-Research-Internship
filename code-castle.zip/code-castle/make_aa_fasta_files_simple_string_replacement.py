#!/usr/bin/env python

"""
make_aa_fasta_files_simple_string_replacement.py -i input.list
Creates a .bash file with scripts that run /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/scripts/rename_mito_proteins.py on specified portalIDs in the form
/global/cfs/cdirs/fnglanot/projects/Multiomics/mito/scripts/rename_mito_proteins.py --dbid XylFL0662B --fasta /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/annotation/XylFL0662B/XylFL0662B_MitochondrionScaffolds.pro --outfile /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/annotation/XylFL0662B/XylFL0662B_MitoAssemblyScaffolds.aa.fasta
Producing these from string replacement
"""

import sys, os, argparse
parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter,usage='',description='')
parser.add_argument('-i', '--input', default=None, help='input file with list of portalIDs to be used in .bash file')

help = 'Usage: make_aa_fasta_files_simple_string_replacement.py -i input.list'
if len(sys.argv) < 2:
    print(help)
    parser.print_help()
    exit()

ARGS = parser.parse_args()
INPUT = ARGS.input

portalIDs = open(os.path.abspath(INPUT), 'r')
for portalID in portalIDs:
	#print(type(portalID))
	cmnd = "/global/cfs/cdirs/fnglanot/projects/Multiomics/mito/scripts/rename_mito_proteins.py --dbid {id} --fasta /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/annotation/{id}/{id}_MitoAssemblyScaffolds.pro --outfile /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/annotation/{id}/{id}_MitoAssemblyScaffolds.aa.fasta\n".format(id=portalID.strip('\n'))
	sys.stdout.write(cmnd)
	cmnd = "/global/cfs/cdirs/fnglanot/projects/Multiomics/mito/scripts/rename_mito_proteins.py --dbid {id} --fasta /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/annotation/{id}/{id}_MitochondrionScaffolds.pro --outfile /global/cfs/cdirs/fnglanot/projects/Multiomics/mito/annotation/{id}/{id}_MitoAssemblyScaffolds.aa.fasta\n".format(id=portalID.strip('\n'))
	sys.stdout.write(cmnd)
