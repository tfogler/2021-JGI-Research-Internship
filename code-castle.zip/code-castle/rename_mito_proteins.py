#!/usr/bin/env python
###created by sjmondo on 2021-07-08 13:21:10.958094###
"""
rename_mito_proteins.py --dbid dbId --fasta proteins.fasta --outfile proteins_out.fasta
take proteins, currently named like "m1", "m2", etc and rename like so: jgi|portal_id|mX|cox1
"""
import sys, os, argparse
sys.path.append(os.path.abspath("/global/u2/s/sjmondo/git/jgi-mycocosm-pipeline/analysis/common/"))
parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter,usage='rename_mito_proteins.py --dbid dbId --fasta proteins.fasta --outfile proteins_out.fasta',description='take proteins, currently named like "m1", "m2", etc and rename like so: jgi|portal_id|mX|cox1')
parser.add_argument('-f', '--fasta', default=None, help='fasta file of mito protein seqs')
parser.add_argument('-o', '--outfile', default=None, help='outfile name')
parser.add_argument('-d', '--dbid', default=None, help='dbid')

if len(sys.argv) < 2:
    parser.print_help()
    exit()

from file_functions_sjm import gzopen
from Bio import SeqIO

def rename_mito(fasta, dbid):
    """take proteins and rename like so: jgi|portal_id|mX|productName"""
    updated_proteins_dict = {}
    for record in SeqIO.parse(open(fasta), 'fasta'):
        description = record.description
        identifier = record.id
        seq = record.seq
        product_name = description.split('## ')[1].strip('\n')
        new_identifier = 'jgi|%s|%s|%s' % (dbid, identifier, product_name)
        new_description = ' '.join(description.split(' ## ')[0].split()[1:])
        new_header = new_identifier + ' ' + new_description
        updated_proteins_dict[new_header] = seq
    return updated_proteins_dict

if __name__ == "__main__":
    ARGS = parser.parse_args()
    FASTA = ARGS.fasta
    OUTFILE = ARGS.outfile
    DBID = ARGS.dbid
    UPDATED_DICT = rename_mito(FASTA, DBID)
    OUT = open(OUTFILE, 'w')
    for record in UPDATED_DICT:
        OUT.write('>%s\n%s\n' % (record, UPDATED_DICT[record]))
