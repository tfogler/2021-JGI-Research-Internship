#!/usr/bin/env python3
"""open file and read it, split all the lines
conditional: if the line is header, store the name and function
else keep count of lengths of lines until hitting the next header
"if line.startswith('>')"
"""
#sys.stdout.write()
import sys

try: portalIDs = sys.argv[1:] #should receive the arguments passed to script!
# pass portalIDs as the list
except IndexError:
    print('Usage: {} paths-of-pro-files'.format(sys.argv[0]))
    exit()

for portalID in portalIDs:
    #print(portalID)
    path_pro = '/global/projectb/sandbox/fungal/analysis/Multiomics/mito/annotation/' + portalID + '/' + portalID + '_MitoAssemblyScaffolds.pro'
    path_gff = path_pro.replace('.pro', '.gff')
    #print(path_pro, path_gff)
    ## this is the part where I unpack the pro file assoc. with the portalID
    with open(path_pro,'r') as pro:
        #
        headers_pro = []
        sequence_lengths = []
        #print(sequence_lengths)
        count = 0 #sums lines in paragraph, before next header
        for line in pro:
            #iterate now
            if line.startswith('>'):
                #parse the header here
                parsedtongue = line.strip( '\n>' ).split(' ')
                headers_pro.append( parsedtongue[0] + '\t' + parsedtongue[-1] )
                ## above splits fas header line and extracts only the id and predicted function
                ## zeroth item in this format = id & last item = name of function {eg nad2)
                if count > 0:
                    sequence_lengths.append(count)
                    count = 0
            else:
                count += len( line.strip() ) #update the running count
        sequence_lengths.append( count )
    
        ## wanted: runescape gff
        with open(path_gff, 'r') as gff:
            #create header array for attribute names
            headers_gff = []
            for line in gff:
                #print(line)
                #parse the gff line-by-line
                if line.startswith('#'):
                    pass
                else:
                    parsedline = line.strip().split('\t')
                    if parsedline[2] == 'CDS':
                        #do something here
                        parsedline_attribute = (parsedline[-1].split("product=")[-1])
                        if parsedline_attribute not in headers_gff and parsedline_attribute.lower() != "hypothetical protein":
                            headers_gff.append(parsedline_attribute)
                        cds_length = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1 #MAYBE I HAVE TO STRIP THE > < SYMBOLS
                        print(cds_length,end=' ')
        
    #with open('%s_gff_attributes_list_uniq.txt' % portalID, 'w') as file:
    #    for attribute in headers_gff:
    #        file.write('%s,' % attribute)
    
    headers_seq_lens_dict = dict(zip( headers_pro, sequence_lengths ))
    

    for header in headers_seq_lens_dict:
        print(portalID, end='\t')
        print('{0}\t{1}'.format(header, headers_seq_lens_dict.get(header)))
