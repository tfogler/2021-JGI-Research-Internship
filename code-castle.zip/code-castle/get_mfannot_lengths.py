#!/usr/bin/env python3
"""
Opens .gff and .pro file corresponding to the PortalID
and reads it to find length of CDS of each predicted gene.
Produces two output files with lists in following format:
PortalID	ID	Gene	Amino Acid from PRO	Amino Acid from GFF	CDS Length from GFF
Theglo1	m1	nad5	1230	1230	410
Theglo1	m2	cox2	987678
Aoaor1 m1--nad5 ----8797
Aoaor1 m2-cox1----8496433
One output file for .gff s and one output file for .pro s
"""

#sys.stdout.write()
import sys, re, os, glob
from os.path import exists
#re = regular expression
import datetime as dt
#datetime module

portalID_file = sys.argv[1] #should receive the arguments passed to script!
# pass portalIDs as the list
#except IndexError:
#  print('Usage: {} paths-of-pro-files'.format(sys.argv[0]))
#  exit()

ts = dt.datetime.now() #datetime object
print("Job started at", ts)

## generating a unique identifier for the files we will append to so that we
## 1) don't create a new file every loop and 2) avoid appendding to old files
## we generate it, unique_file_name, with the first 4 portalIDs and dt module
unique_file_name, i = "Output", 0
#while (i<len(portalIDs)) and (i<4):
#  unique_file_name += portalIDs[i]+'_'
#  i += 1
unique_file_name += ts.strftime("%m-%d-%H-%M_") # date and time added to name
dirname = 'gff_pro_fungal_length_output' #defining output folder path
if not os.path.exists(dirname):
  os.mkdir(dirname)

with open (portalID_file,'r') as fd:
  for line in fd:
    portalID = line.strip('\n')
#    print(portalID)

    if glob.glob(os.path.join('/global/cfs/cdirs/fnglanot/projects/Multiomics/mito/mfannot', portalID, '*.gff')):
      path_gff = glob.glob(os.path.join('/global/cfs/cdirs/fnglanot/projects/Multiomics/mito/mfannot', portalID, '*.gff'))[0]
      print(path_gff)
      with open(path_gff, 'r') as gff:
        #create header array for attribute names
        headers_gff = [] #for all gene names
        cds_lengths_dict = {} # for cds lengths
        gene_lengths_dic = {} # for whole genes
        gc = 0 # gene count
        for line in gff:
          #print(line)
          #parse the gff line-by-line
          if line.startswith('#'):
            pass #skip the gff header rows
          else:
            ### split the 'attribute' column of the gff to find id and gene name
            ### find length of thing from subtracting line coordinates stored in l
            ### for CDS lines append the length l to the cds_lengths_dict
            parsedline = line.strip().split('\t')
            if parsedline[2] == 'gene' or parsedline[2] == 'tRNA' or parsedline[2] == 'rRNA':
              gc += 1
            else:
              if parsedline[2] == 'CDS':
                attr_list = re.split(';', parsedline[-1]) #re module will split it by both = and ;
                gene_id = re.sub(r'ID=','',attr_list[0])
                #gene_name = attr_list[1].strip("Name=")
                gene_name = re.sub(r'gene=','',attr_list[3])

                parsedline_attribute = 'm' + str(gc) + '\t' + gene_name#parsedline_attr[1]#+'\t'+parsedline_attr[3]

                
                if parsedline[3] == "":
                  parsedline[3] = "0"
                if parsedline[4] == "":
                  parsedline[4] = "0"

                cds_len = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1 # HAVE TO STRIP THE > <

                #print('{0}\t{1}\t{2}\t{3}\t{4}'.format(portalID, gene_id, gene_name, cds_len // 3, cds_len))
                #adding CDS lengths and gene names to the respective arrays
                if parsedline_attribute in headers_gff:
                  cds_lengths_dict[parsedline_attribute] += cds_len
                else:
                  cds_lengths_dict[parsedline_attribute] = cds_len
                  headers_gff.append(parsedline_attribute)

    with open(os.path.join(dirname, '%sCDS_count_list.tab' % unique_file_name), 'a') as file:
      for header in headers_gff:
        file.write('{0}\t{1}\t{2}\t{3}\n'.format(portalID, header, cds_lengths_dict.get(header) // 3, cds_lengths_dict.get(header)))
