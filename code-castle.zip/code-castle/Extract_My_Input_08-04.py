#!/usr/bin/env python3
import os, glob
#re = regular expression

input = """Stael1
Asptra1
Aspchev1
Aspegy1
Asppeni1
Aspfalc1
Aspfru1
Aspdese1
Asprec1_1
Aspstec1_1""".splitlines()
print(input)
#try: portalIDs = sys.argv[1:] #should receive the arguments passed to script!
# pass portalIDs as the list
#except IndexError:
#    print('Usage: {} paths-of-pro-files'.format(sys.argv[0]))
#    exit()
dirname = 'plot_comp_mito_gff_input' #defining output folder path
if not os.path.exists(dirname):
    os.mkdir(dirname)
output = open(os.path.join(dirname, ('_'.join(input)+'input.gff')), 'w')
output.close()
for portalID in input:
    path_gff = glob.glob(os.path.join('/global/projectb/sandbox/fungal/analysis/Multiomics/mito/annotation', portalID, '*.gff'))[0]
    path_fa = path_gff.replace('.gff','.fasta')
    
    with open(os.path.join(dirname, ('_'.join(input)+'input.gff')), 'a') as o:
        o.write('{0}\t{1}\t{2}\n'.format(portalID,path_fa,path_gff))