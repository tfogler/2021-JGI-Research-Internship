#!/usr/bin/env Rscript
# Script: plot.R
# Description:  
# Author: Steven Ahrendt
# email: sahrendt0@gmail.com
# Date: 07.15.2021
##################################
args <- commandArgs(trailingOnly=TRUE)
#####-----Libraries-----#####
library(ggplot2)

#####-----Functions-----#####

#####-----Main-----#####
## Read the file as a dataframe
dat <- read.delim("Acema1_Aciaci1_AcreTS7_1_Acrst1_No_Hypo_LAGLIDADG_GIYYIG_CDS_count_list.tab", header=F)

## Change the column headers to be more meaningful
colnames(dat) <- c("dbid","gene","name","len1","len2","len3")

## Draw a plot and save as "plotto.png"
png("plotto.png")
ggplot(dat,aes(x=name,y=len1)) + geom_boxplot()
dev.off()
