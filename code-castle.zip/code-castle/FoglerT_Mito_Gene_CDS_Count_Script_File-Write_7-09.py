#!/usr/bin/env python3
"""
Opens .gff and .pro file corresponding to the PortalID
and reads it to find length of CDS of each predicted gene.
Produces two output files with lists in follwing format:
PortalID	id	gene	CDS length
Theglo1	m1	nad5	1232
Theglo1	m2	cox2	987678
Aoaor1 m1--nad5 ----8797
Aoaor1 m2-cox1----8496433
One output file for .gff s and one output file for .pro s
"""

#sys.stdout.write()
import sys
import re
#re = regular expression
import datetime as dt
#datetime module

try: portalIDs = sys.argv[1:] #should receive the arguments passed to script!
# pass portalIDs as the list
except IndexError:
    print('Usage: {} paths-of-pro-files'.format(sys.argv[0]))
    exit()

ts = dt.datetime.now() #datetime object
print("Job started at", ts)

## generating a unique identifier for the files we will append to so that we
## 1) don't create a new file every loop and 2) avoid appendding to old files
## we generate it, unique_file_name, with the first 4 portalIDs and dt module
unique_file_name, i = "", 0
while (i<len(portalIDs)) and (i<4):
    unique_file_name += portalIDs[i]+'_'
    i += 1
unique_file_name += ts.strftime("%m-%d-%H-%M_") # date and time added to name


for portalID in portalIDs:
    #print(portalID)
    path_pro = '/global/projectb/sandbox/fungal/analysis/Multiomics/mito/annotation/' + portalID + '/' + portalID + '_MitoAssemblyScaffolds.pro'
    #path_pro = './'+ portalID + '_MitoAssemblyScaffolds.pro'
    path_gff = path_pro.replace('.pro', '.gff')
    #print(path_pro, path_gff)
    ## this is the part where I unpack the pro file assoc. with the portalID
    with open(path_pro,'r') as pro:
        #
        headers_pro = []
        sequence_lengths = []
        #print(sequence_lengths)
        count = 0 #sums lines in paragraph, before next header
        for line in pro:
            #iterate now
            if line.startswith('>'):
                #parse the header here
                parsedtongue = line.strip( '\n>' ).split(' ')
                headers_pro.append( parsedtongue[0] + '\t' + parsedtongue[-1] )
                ## above splits fas header line and extracts only the predicted gene function
                ## zeroth item in this format = id & last item = name of function {eg nad2)
                if count > 0:
                    sequence_lengths.append(count)
                    count = 0
            else:
                count += len( line.strip() ) #update the running count
        sequence_lengths.append( count )
    headers_seq_lens_dict = dict(zip( headers_pro, sequence_lengths ))
    
    ## wanted: runescape gff
    with open(path_gff, 'r') as gff:
        #create header array for attribute names
        headers_gff = [] #for all names
        cds_lengths_dict = {} # for cds lengths
        gene_lengths_dic = {} # for whole genes
        for line in gff:
            #print(line)
            #parse the gff line-by-line
            if line.startswith('#'):
                pass #skip the gff header rows
            else:
                ### split the 'attribute' column of the gff to find id and gene name
                ### find length of thing from subtracting line coordinates stored in l
                ### for CDS lines append the length l to the cds_lengths_dict
                parsedline = line.strip().split('\t')
                parsedline_attr = re.split('=|;', parsedline[-1]) #re module will split it by both = and ;
                parsedline_attribute = parsedline_attr[1]+'\t'+parsedline_attr[3]
                l = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1 # HAVE TO STRIP THE > <
                #print(parsedline_attr[1],parsedline_attr[3],l)
                #if parsedline[2] == 'gene':
                
                if parsedline[2] == 'CDS':
                    #adding CDS lengths and gene names to the respective arrays
                    if parsedline_attr[3] == "hypothetical protein": # want it to say hypo not hypothetical protein
                        parsedline_attribute = parsedline_attr[1]+'\t'+'hypo'
                    if parsedline_attribute in headers_gff:
                        cds_lengths_dict[parsedline_attribute] += l
                    else:
                        cds_lengths_dict[parsedline_attribute] = l
                    headers_gff.append(parsedline_attribute)
                
                #if parsedline[2].lower() == 'gene':
                #    headers_gff.append(parsedline_attribute)
                #    gene_length = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1
	            #    sequence_lengths_gen.append(gene_length)
	            #    sequence_lengths_cds.append(cds_length)
                #if parsedline[2] == 'CDS':
                #    #adding CDS lengths and gene names to the respective arrays
                #    if parsedline_attribute not in headers_gff and parsedline_attribute.lower() != "hypothetical protein":
	            #        cds_length = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1 #MAYBE I HAVE TO STRIP THE > < SYMBOLS
	            #    elif: parsedline_attribute in headers_gff:
	            #        cds_length += int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1
        #sequence_lengths_cds.append(cds_length)

                    #print(cds_length,end=' ')
                    #print(parsedline_attribute, cds_length)


        
    with open('%spro_CDS_count_list.tab' % unique_file_name, 'a') as file:
        for header in headers_seq_lens_dict:
            file.write('{0}\t{1}\t{2}\n'.format(portalID, header, headers_seq_lens_dict.get(header)*3))
    with open('%sgff_CDS_count_list.tab' % unique_file_name, 'a') as file:
        for header in cds_lengths_dict:
            file.write('{0}\t{1}\t{2}\n'.format(portalID, header, cds_lengths_dict.get(header)))
    

    #for header in headers_seq_lens_dict:
        #print(portalID, end='\t')
        #print('{0}\t{1}'.format(header, headers_seq_lens_dict.get(header)*3))
    #for header in cds_lengths_dict:
        #print(portalID, end='\t')
        #print('{0}\t{1}'.format(header, cds_lengths_dict.get(header)))