#!/usr/bin/env python3
"""open file and read it, split all the lines
conditional: if the line is header, store the name and function
else keep count of lengths of lines until hitting the next header
"if line.startswith('>')"
"""

import sys

try: file_path = sys.argv[1] #should receive the first argument passed to script!
except IndexError:
    print('Usage: {} path-of-pro-file'.format(sys.argv[0]))
    exit()

with open(file_path,'r') as file:
    #shit = file.read().splitlines()
    headers = []
    sequence_lengths = []
    #print(sequence_lengths)
    count = 0 #sums lines in paragraph, before next header
    for line in file:
        #iterate now
        if line.startswith('>'):
            #parse the header here
            parsedtongue = line.strip( '\n>' ).split(' ')
            headers.append( parsedtongue[0] + ',' + parsedtongue[-1] )
            ## above splits fas header line and extracts only the id and predicted function
            ## zeroth item in this format = id & last item = name of function {eg nad2)
            if count > 0:
                sequence_lengths.append(count)
                count = 0
        else:
            count += len( line.strip() ) #update the running count
    sequence_lengths.append( count )

headers_seq_lens_dict = dict(zip( headers, sequence_lengths ))
for anything in headers_seq_lens_dict.keys():
    print('{0},{1}'.format(anything, headers_seq_lens_dict.get(anything)))
