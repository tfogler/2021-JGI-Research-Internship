#!/usr/bin/env python3
"""open file and read it, split all the lines
conditional: if the line is header, store the name and function
else keep count of lengths of lines until hitting the next header
if line.startswith('>')
"""
#sys.stdout.write()
import sys



try: file_paths = sys.argv[1:] #should receive the arguments passed to script!
except IndexError:
    print('Usage: {} paths-of-pro-files'.format(sys.argv[0]))
    exit()
#func_name=sys.argv[1] #the name of the gene you search for

for file_path in file_paths:
	with open(file_path, 'r') as fl:
		for line in fl:
			if line.startswith('>'):
				header = line.strip('\n>').split(' ')
				j = int(header[3])
				k = int(header[2])
				l = j - k
				sys.stdout.write(file_path+'\t'+header[0]+'\t'+header[9]+'\t'+str(l)+'\n')

"""
for file_path in file_paths:
    #print(file_path)
    with open(file_path,'r') as file:
        #shit = file.read().splitlines()
        headers = []
        sequence_lengths = []
        #print(sequence_lengths)
        count = 0 #sums lines in paragraph, before next header
        for line in file:
            #iterate now
            if line.startswith('>'):
                #parse the header here
                parsedtongue = line.strip( '\n>' ).split(' ')
                headers.append( parsedtongue[0] + '\t' + parsedtongue[-1] )
                ## above splits fas header line and extracts only the id and predicted function
                ## zeroth item in this format = id & last item = name of function {eg nad2)
                if count > 0:
                    sequence_lengths.append(count)
                    count = 0
            else:
                count += len( line.strip() ) #update the running count
        sequence_lengths.append( count )

    headers_seq_lens_dict = dict(zip( headers, sequence_lengths ))
    
    funny_headers=[]
    for header in headers_seq_lens_dict.keys():
        if func_name in header:
            funny_headers.append(header)
    for header in funny_headers:
        print(file_path, end='\t')
        print('{0}\t{1}'.format(header, headers_seq_lens_dict.get(header)))
"""