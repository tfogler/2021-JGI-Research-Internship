#!/bin/bash

for portalID in `cut -f1 /global/u2/f/foglert/plot_comp_mito_gff_input/8-26_all_asp_t3.txt `;
do mkdir $ANNODIR$portalID/table_3;
done;
