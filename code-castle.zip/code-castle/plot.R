#!/usr/bin/env Rscript
# Script: plot.R
# Description:  
# Author: Steven Ahrendt
# email: sahrendt0@gmail.com
# Date: 07.15.2021
##################################
args <- commandArgs(trailingOnly=TRUE)
#####-----Libraries-----#####
library(ggplot2)

#####-----Functions-----#####

#####-----Main-----#####
## Read the file as a dataframe
dat <- read.delim("/global/u2/f/foglert/gff_pro_fungal_length_output/AnFL0455_Annbov1_Annmae1_Annmin1_10-21-20-44_CDS_count_list.tab",header=F)

## Change the column headers to be more meaningful
colnames(dat) <- c("dbid","gene","name","len1","len2","len3")

## Draw a plot and save as "plot.png"
png("plot.png")
ggplot(dat,aes(x=name,y=len1)) + geom_boxplot()
dev.off()
