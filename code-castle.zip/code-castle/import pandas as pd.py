import pandas as pd

outliers = open('Acema1_Aciaci1_AcreTS7_1_Acrst1_No_Hypo_LAGLIDADG_GIYYIG_CDS_count_list - Acema1_Reformat_3.csv', 'r')

i = 0
for line in outliers:
    if i<5:
        print(line)
        i+=1
    else:
        break