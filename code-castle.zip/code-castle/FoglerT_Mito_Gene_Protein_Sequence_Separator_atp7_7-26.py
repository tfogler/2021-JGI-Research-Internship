#!/usr/bin/env python3
"""Opens Pro file corresponding to the PortalIDs
Reformats and combines into one .pro fasta file
"""
#Output of file
"""
>m#_PortalID\tscaffold_#\tstart-coord\tend-coord\t+-\t1-5\tscore\Algorithm\t##\tfunc_name\n
<<Sequence w/o line breaks>>
>m1_Theglo1 scaffold_1	2	1363	-	1	1270.38	HMM	##	nad5
MYLAIITLPLLGSIVAGFFGRKVGVTGAQIITSLCVILTTLLAIVAFFEVGLNNIPVSINLFKWIDSESLNVLWAFNFDSLTVSMLIPVL...
>m10	scaffold_1	19709	24809	+	3	1218.86	HMM	##	nad5	Metgru1
MFNFLTFKYEEPIQITLFNWISLGNLNINFGILLDPLSMVVMVPIGVVTSAVLFYSLDYMRYDPARNRFYVVLSVFALFMTLLIVSDNYI...
...
>m5_Theglo1	scaffold_1 3180 6507 - 2 1147.27 HMM ## cox1
VIWTFCLTDSHRQSSPFVTYNSNVSDTSALTSPTREEQLTLKSTISLWAERWFLSSNAKDIGTLYLIFALFSGLLGTAFSVLIRLELSGP...
"""

#sys.stdout.write()
import sys, os, glob
#re = regular expression

try: portalIDs = sys.argv[1:] #should receive the arguments passed to script!
# pass portalIDs as the list
except IndexError:
    print('Usage: {} paths-of-pro-files'.format(sys.argv[0]))
    exit()

## generating a unique identifier for the files we will append to so that we
## 1) don't create a new file every loop and 2) avoid appendding to old files
## we generate it, unique_file_name, with the first 4 portalIDs and dt module
unique_file_name, i = "", 0
while (i<len(portalIDs)) and (i<4):
    unique_file_name += portalIDs[i]+'_'
    i += 1
#unique_file_name += ts.strftime("%m-%d-%H-%M_") # date and time added to name
dirname = 'pro_fungal_sequence_output' #defining output folder path
if not os.path.exists(dirname):
    os.mkdir(dirname)

func_name = "atp7"
headers_gene_name_dict = {}
headers_seq_dict = {}
for portalID in portalIDs:
    
    path_pro = glob.glob(os.path.join('/global/projectb/sandbox/fungal/analysis/Multiomics/mito/annotation', portalID, '*.pro'))[0]
    #path_pro = '/global/projectb/sandbox/fungal/analysis/Multiomics/mito/annotation/' + portalID + '/' + portalID + '_MitoAssemblyScaffolds.pro'
    #path_pro = './'+ portalID + '_MitoAssemblyScaffolds.pro'
    #path_gff = path_pro.replace('.pro', '.gff')
    
    ## this is the part where I unpack the pro file assoc. with the portalID
    with open(path_pro,'r') as pro:
        #
        headers_pro = []
        sequence = []
        #print(sequence_lengths)
        seq = '' #sums lines in paragraph, before next header
        for line in pro:
            #iterate now
            if line.startswith('>') and func_name in line:
                #parse the header here
                parsedtongue = line.strip( '\n>' ).split(' ')
                new_header = '\t'.join(parsedtongue[1:])
                new_header = ">{0}_{1}\t{2}\n".format(parsedtongue[0], portalID, new_header)
                headers_pro.append(new_header) #append a header that's unique for every sequence to dict
                ## above splits fas header line and extracts only the predicted gene function
                ## zeroth item in this format = id & last item = name of function {eg nad2)
                if seq:
                    sequence.append(seq)
                    seq = ''
            elif line.startswith('>'):
                seq = ''
            else:
                seq += line.strip() #update the running count
        sequence.append(seq)
    new_headers_seq_dict = dict(zip( headers_pro, sequence ))
    headers_seq_dict.update(new_headers_seq_dict)

#cox1_headers = header for header in headers_seq_dict.keys() if func_name in header

output = open(os.path.join(dirname, unique_file_name+'cox1_pro_fungal_amino-acid_sequences_output.txt'), 'w')
for h in headers_seq_dict.keys():
    output.write('{}{}\n'.format(h, headers_seq_dict.get(h)))
    
output.close()
    
	
"""
## wanted: runescape gff
with open(path_gff, 'r') as gff:
    #create header array for attribute names
    headers_gff = [] #for all names
    cds_lengths_dict = {} # for cds lengths
    gene_lengths_dic = {} # for whole genes
    for line in gff:
        #print(line)
        #parse the gff line-by-line
        if line.startswith('#'):
            pass #skip the gff header rows
        else:
            ### split the 'attribute' column of the gff to find id and gene name
            ### find length of thing from subtracting line coordinates stored in l
            ### for CDS lines append the length l to the cds_lengths_dict
            parsedline = line.strip().split('\t')
            parsedline_attr = re.split('=|;', parsedline[-1]) #re module will split it by both = and ;
            parsedline_attribute = parsedline_attr[1]+'\t'+parsedline_attr[3]
            l = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1 # HAVE TO STRIP THE > <
            #print(parsedline_attr[1],parsedline_attr[3],l)
            #if parsedline[2] == 'gene':
            
            if parsedline[2] == 'CDS':
                #adding CDS lengths and gene names to the respective arrays
                if parsedline_attr[3] == "hypothetical protein": # want it to say hypo not hypothetical protein
                    parsedline_attribute = parsedline_attr[1]+'\t'+'hypo'
                if parsedline_attribute in headers_gff:
                    cds_lengths_dict[parsedline_attribute] += l
                else:
                    cds_lengths_dict[parsedline_attribute] = l
                headers_gff.append(parsedline_attribute)
            
            #if parsedline[2].lower() == 'gene':
            #    headers_gff.append(parsedline_attribute)
            #    gene_length = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1
            #    sequence_lengths_gen.append(gene_length)
            #    sequence_lengths_cds.append(cds_length)
            #if parsedline[2] == 'CDS':
            #    #adding CDS lengths and gene names to the respective arrays
            #    if parsedline_attribute not in headers_gff and parsedline_attribute.lower() != "hypothetical protein":
            #        cds_length = int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1 #MAYBE I HAVE TO STRIP THE > < SYMBOLS
            #    elif: parsedline_attribute in headers_gff:
            #        cds_length += int(parsedline[4].strip('><')) - int(parsedline[3].strip('><')) + 1
    #sequence_lengths_cds.append(cds_length)

                #print(cds_length,end=' ')
                #print(parsedline_attribute, cds_length)



with open(os.path.join(dirname, '%sCDS_count_list.tab' % unique_file_name), 'a') as file:
    for header in headers_seq_lens_dict:
        file.write('{0}\t{1}\t{2}\t{3}\t{4}\n'.format(portalID, header, headers_seq_lens_dict.get(header), cds_lengths_dict.get(header) // 3, cds_lengths_dict.get(header)))
#with open('%sgff_CDS_count_list.tab' % unique_file_name, 'a') as file:
#    for header in cds_lengths_dict:
#        file.write('{0}\t{1}\t{2}\n'.format(portalID, header, cds_lengths_dict.get(header) // 3))


#for header in headers_seq_lens_dict:
    #print(portalID, end='\t')
    #print('{0}\t{1}'.format(header, headers_seq_lens_dict.get(header)*3))
#for header in cds_lengths_dict:
    #print(portalID, end='\t')
    #print('{0}\t{1}'.format(header, cds_lengths_dict.get(header)))
"""