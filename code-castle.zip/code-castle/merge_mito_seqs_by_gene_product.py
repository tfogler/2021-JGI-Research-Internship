#!/usr/bin/env python
###created by sjmondo on 2021-07-08 13:45:46.493989###
###modified by foglert on 2022-01-07 at 7:34:26
"""
merge_mito_seqs_by_gene_product.py --product_name cox1 --outfile cox1_merged.out
combine mito sequences for the same product (ie cox1, nad5, etc) into a single file. This is intended to work only with our current directory structure. If you prefer, it can be rewritten - let me (sjmondo) know.
"""
import sys, os, argparse
sys.path.append(os.path.abspath("/global/u2/s/sjmondo/git/jgi-mycocosm-pipeline/analysis/common/"))
parser = argparse.ArgumentParser(formatter_class=argparse.ArgumentDefaultsHelpFormatter,usage='merge_mito_seqs_by_gene_product.py --product_name cox1 --outfile cox1_merged.out',description='combine mito sequences for the same product (ie cox1, nad5, etc) into a single file. This is intended to work only with our current directory structure. If you prefer, it can be rewritten - let me (sjmondo) know.')
parser.add_argument('-p', '--product_name', default=None, help='product name, ie cox1, cob, etc.')
parser.add_argument('-o', '--outfile', default=None, help='outfile name')
parser.add_argument('-dp', '--datapath', default='/global/cfs/projectdirs/fnglanot/projects/Multiomics/mito/annotation/', help='top level path to find data files')
parser.add_argument('-sc', '--single_copy_per_product', default='yes', help='if multiple copies exist of the same product, pick the one closest to the mean length and discard the rest.')
parser.add_argument('-id', '--portal_id', default=None, help='infile with list of portalIDs to limit search to')

if len(sys.argv) < 2:
    parser.print_help()
    exit()

from file_functions_sjm import gzopen
from Bio import SeqIO

def desired_portalIDs(portalIDs):
    """extract list of portalIDs permitted from --portal_id file, if supplied"""
    if portalIDs:
        portalID_path = os.path.abspath(portalIDs)
        portalID_set = set()
        with open(portalID_path, 'r') as portalID_list:
            for portalID in portalID_list:
                portalID_set.add(portalID.strip('\n'))
        #print(portalID_set)
        return portalID_set
    else:
        return None

def check_portalID(portalID_set, name):
    """limit the *.aa.fasta files combined to those specified in a portalID list, if supplied"""    
    if portalID_set:
        return name in portalID_set
    else:
        return True


def collect_seqs(product_name, datapath, portalIDs):
    """use pre-configured path to grab all *.aa.fasta files across various organisms and put them into a single file"""
    portalID_set = desired_portalIDs(portalIDs)
    basedir = os.path.abspath(datapath)
    lineages = os.listdir(basedir)
    res = {}
    for lineage in lineages:
        #bool = check_portalID(portalID_set, lineage)
        #print(lineage, bool)
        if check_portalID(portalID_set, lineage):
            try:
                for infile in os.listdir('%s/%s' % (basedir, lineage)):
                    if infile.endswith('.aa.fasta'):
                        for record in SeqIO.parse(open('%s/%s/%s' % (basedir, lineage, infile)), 'fasta'):
                            product = record.id.split('|')[-1]
                            if product == product_name:
                                res[record.id] = record.seq
            except NotADirectoryError as e:
                sys.stderr.write('%s is not recognized as a directory. skipping\n' % (lineage))
        else:
            #sys.stderr.write('%s is not recognized as a directory. skipping\n' % (lineage))
            pass
    return res

def find_best_copy(dbid, choices, product_name):
    """take all choices to represent a specific dbid, then pick the one that is the closest to the mean aa length. Discard the rest."""
    mean_lens = {'atp6' : 271.89,
                 'atp8' : 55.13,
                 'atp9' : 90.92,
                 'cob' : 384.23,
                 'cox1' : 537.47,
                 'cox2' : 269.79,
                 'cox3' : 287.25,
                 'nad1' : 344.76,
                 'nad2' : 542.15,
                 'nad3' : 174.21,
                 'nad4' : 484.22,
                 'nad4L' : 104.21,
                 'nad5' : 635.68,
                 'nad6' : 231.42}
    print('WARNING: %s has more than 1 copy of %s. Selecting a single protein representative with length closest to the mean for %s (%s AA)' % (dbid, product_name, product_name, mean_lens[product_name]))
    distances = []
    for choice in choices:
        length = len(choice[1])
        distances.append(abs(length-mean_lens[product_name]))
    return choices[distances.index(min(distances))]  # find the index of the seq record that is closest in size to the mean for that product

if __name__ == "__main__":
    ARGS = parser.parse_args()
    PRODUCT_NAME = ARGS.product_name
    OUTFILE = ARGS.outfile
    DATAPATH = ARGS.datapath
    PORTALIDS = ARGS.portal_id
    SEQS = collect_seqs(PRODUCT_NAME, DATAPATH, PORTALIDS)
    OUT = open(OUTFILE, 'w')
    SINGLE_COPY_REQUESTED = ARGS.single_copy_per_product
    DBID_SORTED = {}
    for seq in SEQS:
        if seq.split('|')[1] not in DBID_SORTED:
            DBID_SORTED[seq.split('|')[1]] = [[seq, SEQS[seq]]]
        else:
            DBID_SORTED[seq.split('|')[1]].append([seq, SEQS[seq]])
    SEQS_FINAL = {}
    if SINGLE_COPY_REQUESTED == 'yes':
        for dbid in DBID_SORTED:
            if len(DBID_SORTED[dbid]) > 1:
                best_match = find_best_copy(dbid, DBID_SORTED[dbid], PRODUCT_NAME)
                SEQS_FINAL[best_match[0]] = best_match[1]
            else:
                SEQS_FINAL[DBID_SORTED[dbid][0][0]] = DBID_SORTED[dbid][0][1]
    for seq in SEQS_FINAL:
        OUT.write('>%s\n%s\n' % (seq, SEQS[seq]))
