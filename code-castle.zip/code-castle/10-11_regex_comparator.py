#!/usr/bin/env python3

import re, sys

def comparator4(substring, searchstring):
     if len(substring) == 0:
             return ''
     elif substring[0] != searchstring[0]:
             return '-' + comparator4(substring[1:], searchstring)
     for i in range(len(substring)):
             comparison = re.search(substring[0:i+1], searchstring)
             if not comparison:
                     return substring[0:i] + '-' + comparator4(substring[i+1:], searchstring[i:])
     return comparison
with open('/global/u2/f/foglert/code-castle/10-11_string_input.txt', 'r') as input:
    i=0
    for item in input:
        i+=1
        if i%2==1:
            string1 = item
        else:
            string2 = item
    sys.stdout.write(comparator4(string2, string1))