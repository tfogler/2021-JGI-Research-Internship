#!/usr/bin/env python3

import sys, os, glob
#portalID = 'Aspacri1'
portalID = 'XylFL0622B'
#path_pro = glob.glob(os.path.join('/global/projectb/sandbox/fungal/analysis/Multiomics/mito/annotation', portalID, '*.pro'))[0]
#print(path_pro)
path_pro = os.path.join('/global/cscratch1/sd/foglert', portalID, 'table_4', '*.pro')
print(path_pro)